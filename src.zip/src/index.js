import { initStore } from './store/index';
import './index.scss';

initStore();
